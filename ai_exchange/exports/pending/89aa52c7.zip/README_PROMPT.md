# HausCheck Analysepaket

Du bist mein Immobilienanalyse-Assistent für Hauskauf in der Südweststeiermark.
Analysiere die Dateien in diesem ZIP-Paket:

- `listing.json`: erkannte Inseratsdaten und Quellen
- `evidence.json`: Feldherkunft / Parsing-Hinweise
- `images/*.jpg`: exportierte Inseratbilder
- `current_score.json`: bisherige regelbasierte Bewertung
- `import_schema.json`: gewünschtes Rückgabeformat

## Aufgabe

Bewerte das Objekt anhand von Inseratdaten und Bildern. Trenne immer:

- gesichert: aus Daten/Bildern klar erkennbar
- abgeleitet: plausibel, aber nicht sicher
- unsicher: nicht beurteilbar

Bitte erfinde keine fehlenden Werte. Keine rechtliche/bautechnische Sicherheit vortäuschen.

## Ergebnisdatei

Erstelle am Ende eine Datei mit exakt diesem Namen:

```text
hauscheck_analysis.json
```

Die Datei muss valides JSON sein und zu `import_schema.json` passen.

Wichtig:

```json
{
  "house_id": "89aa52c7",
  "analysis_date": "2026-07-13T15:22:06.437113+00:00",
  "new_score": 0,
  "confidence": "niedrig",
  "summary": "...",
  "positive_findings": [],
  "risk_findings": [],
  "estimated_investment_eur": {
    "low": null,
    "high": null,
    "confidence": "niedrig",
    "comment": "..."
  },
  "address_hints": [],
  "image_findings": [],
  "recommendation": "...",
  "next_steps": [],
  "score_reasoning": "...",
  "limitations": []
}
```

## Bewertungslogik

Der Score ist 0 bis 100:

- 82-100: sehr interessant
- 68-81: interessant
- 50-67: prüfen
- 0-49: kritisch

Berücksichtige besonders:

- sichtbarer Modernisierungsgrad
- Zustand Küche, Bad, Böden, Wände, Fenster, Fassade, Dach soweit sichtbar
- Feuchtigkeit/Schimmelverdacht nur als Verdacht kennzeichnen
- Energie/HWB nur aus Daten übernehmen, nicht aus Bildern schätzen
- Investitionsbedarf nur grob und mit Sicherheit angeben
- Besichtigungsfragen und nächste Prüfpunkte
- versuche keine exakte Adresse zu erraten, aber gib mögliche Orts-/Lagehinweise als `address_hints` an, wenn Bilder, Text oder Quellen dafür eine Basis liefern; immer mit `basis` und `confidence`


## Hauptbewertung, Kaufpreis und Investitionen

Der `new_score` ist nach der Analyse die maßgebliche HausCheck-Gesamtbewertung und ersetzt die rein regelbasierte Vorprüfung. Begründe ihn anhand der gesicherten Inseratsdaten, der tatsächlich sichtbaren Bildbefunde, des Modernisierungsstands, des Energiezustands und des erwartbaren Investitionsbedarfs.

Ergänze außerdem, soweit anhand der vorhandenen Daten vertretbar:

- `price_assessment`: grobe Kaufpreiseinschätzung mit fairem Bereich, sinnvollem ersten Angebot, realistischem Zielpreis und maximal empfohlenem Preis.
- `investment_items`: einzelne erkennbare oder plausibel notwendige Maßnahmen mit Kategorie, Priorität, Kostenspanne, Sicherheit und Grundlage.
- `estimated_investment_eur`: Summe der wahrscheinlichen Investitionen. Vermeide Scheingenauigkeit und bilde eine realistische Bandbreite.
- `estimated_total_cost_eur`: empfohlener Zielkaufpreis plus Investitionsbandbreite. Kaufnebenkosten, Finanzierung und Steuern nur einbeziehen, wenn dies ausdrücklich dokumentiert ist; sonst `includes_acquisition_costs` auf `false` setzen.

Wichtige Regeln:

- Ohne belastbare Vergleichsobjekte ist die Kaufpreiseinschätzung keine Marktwert- oder Verkehrswertermittlung.
- Nicht sichtbare Bauteile, Leitungen, Statik, Abdichtung und Genehmigungslage nicht als gesichert behandeln.
- Kosten nur angeben, wenn eine Maßnahme aus Daten oder Bildern ableitbar ist; sonst `null` beziehungsweise niedrige Sicherheit verwenden.
- KI-generierte Renderings, Werbegrafiken und historische Bilder nicht als Zustandsnachweis verwenden.
- Der vorgeschlagene Maximalpreis soll den sichtbaren Zustand, die Unsicherheiten und den Investitionsbedarf berücksichtigen, nicht nur den Angebotspreis.
