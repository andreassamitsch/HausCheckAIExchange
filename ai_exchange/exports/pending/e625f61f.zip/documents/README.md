# Exposé-Unterlagen

Textdateien sind die kompakte Primärquelle. Original-PDFs werden nur aufgenommen, wenn das gesamte Analysepaket unter dem Sicherheitsbudget bleibt. Adressvorschläge müssen anhand ihres Status im Manifest behandelt werden.
